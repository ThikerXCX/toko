<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PenjualanResource\Pages;
use App\Filament\Resources\PenjualanResource\RelationManagers;
use App\Models\Penjualan;
use App\Traits\FilamentPermissionAwareNavigation;
use BezhanSalleh\FilamentShield\Contracts\HasShieldPermissions;
use Filament\Tables\Actions\Action;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class PenjualanResource extends Resource implements HasShieldPermissions
{
    use FilamentPermissionAwareNavigation;
    protected static string $requiredPermission = 'view_penjualan';
    public static function shouldRegisterNavigation(): bool
    {
        return static::canAccessMenu(); // Panggil method yang sudah aman
    }
    protected static ?string $model = Penjualan::class;
    protected static ?string $navigationGroup = 'Transaksi';
    protected static ?string $navigationLabel = 'Penjualan';

    protected static ?string $navigationIcon = 'heroicon-o-shopping-cart';


    public static function form(Form $form): Form
    {
        function updateTotal(callable $set, callable $get): void {
            $details = $get('details') ?? [];
            $total = collect($details)->sum(fn($d) => ($d['harga'] ?? 0) * ($d['qty'] ?? 0));
            $set('total', $total);
        }
        return $form->schema([
            DatePicker::make('tanggal')
                ->label('Tanggal')
                ->readOnly()
                ->default(now()),

            TextInput::make('total')
                ->numeric()
                ->readOnly()
                ->default(0),

            Repeater::make('details')
                ->relationship()
                ->label('Detail Penjualan')
                ->schema([
                    // Select::make('product_id')
                    //     ->label('Produk')
                    //     ->relationship('product', 'name')
                    //     ->required()
                    //     ->searchable()
                    //     ->reactive()
                    //     ->afterStateUpdated(function ($state, callable $set, callable $get) {
                    //         if ($state) {
                    //             $hargaJual = \App\Models\Product::find($state)?->harga_jual ?? 0;
                    //             $set('harga', $hargaJual);
                    //             $set('qty', 1);
                    //             $set('subtotal', $hargaJual * 1);

                    //             // Cukup hitung total dari details, JANGAN tambah manual subtotal baris ini
                    //             $details = $get('../../details') ?? [];
                    //             $total = collect($details)->sum(fn ($item) => ($item['harga'] ?? 0) * ($item['qty'] ?? 0));
                    //             $set('../../total', $total);
                    //         }
                    //     }),

                    Select::make('product_id')
                    ->label('Produk')
                    ->required()
                    ->searchable()
                    ->options(function (callable $get) {
                        $selectedProducts = collect($get('../../details'))
                            ->pluck('product_id')
                            ->filter()
                            ->toArray();

                        return \App\Models\Product::query()
                            ->when($selectedProducts, fn ($query) => $query->whereNotIn('id', $selectedProducts))
                            ->pluck('name', 'id');
                    })
                    ->reactive()
                    ->afterStateUpdated(function ($state, callable $set, callable $get) {
                        if ($state) {
                            $hargaJual = \App\Models\Product::find($state)?->harga_jual ?? 0;
                            $set('harga', $hargaJual);
                            $set('qty', 1);
                            $set('subtotal', $hargaJual * 1);

                            $details = $get('../../details') ?? [];
                            $total = collect($details)->sum(fn ($item) => ($item['harga'] ?? 0) * ($item['qty'] ?? 0));
                            $set('../../total', $total);
                        }
                    }),

                    TextInput::make('harga')
                        ->numeric()
                        ->required()
                        ->label('Harga')
                        ->lazy()
                        ->afterStateUpdated(function ($state, callable $set, callable $get) {
                            $qty = $get('qty') ?? 0;
                            $set('subtotal', (int)$state * (int)$qty);

                            // Update total di parent
                            $details = $get('../../details') ?? [];
                            $total = collect($details)->sum(fn ($item) => ($item['harga'] ?? 0) * ($item['qty'] ?? 0));
                            $set('../../total', $total);
                        }),

                    TextInput::make('qty')
                        ->numeric()
                        ->required()
                        ->default(1)
                        ->label('Jumlah')
                        ->lazy()
                        ->maxValue(fn (callable $get) => \App\Models\Product::find($get('product_id'))?->stok ?? null)
                        ->afterStateUpdated(function ($state, callable $set, callable $get) {
                            $productId = $get('product_id');
                            $stok = \App\Models\Product::find($productId)?->stok ?? null;
                            $qty = (int)$state;

                            if ($stok !== null && $qty > $stok) {
                                $qty = $stok;
                                $set('qty', $qty);

                                Notification::make()
                                    ->title('Jumlah melebihi stok!')
                                    ->body('Jumlah otomatis diubah ke stok maksimal: ' . $stok)
                                    ->danger()
                                    ->send();
                            }

                            $harga = $get('harga') ?? 0;
                            $set('subtotal', (int)$harga * $qty);

                            // Update total di parent
                            $details = $get('../../details') ?? [];
                            $total = collect($details)->sum(fn ($item) => ($item['harga'] ?? 0) * ($item['qty'] ?? 0));
                            $set('../../total', $total);
                        }),

                    TextInput::make('subtotal')
                        ->numeric()
                        ->readOnly()
                        ->label('Subtotal'),
                ])
                ->columns(2)
                ->required()
                ->reactive()
                // Optional: tetap tambahkan afterStateUpdated di repeater untuk sync jika ada tambah/hapus baris
                ->afterStateUpdated(function (callable $set, callable $get) {
                    $details = $get('details') ?? [];
                    $total = collect($details)->sum(fn ($item) => ($item['harga'] ?? 0) * ($item['qty'] ?? 0));
                    $set('total', $total);
                })
                ->columnSpanFull(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('kode')
                    ->label('Kode Penjualan')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('user.name')
                    ->label('Dilayani Oleh')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('tanggal')
                    ->label('Tanggal')
                    ->date()
                    ->sortable()
                    ->searchable(),
                TextColumn::make('total')
                    ->label('Total')
                    ->money('idr')
                    ->sortable()
                    ->searchable(),
                
            ])
            ->filters([
                //
            ])
            ->actions([
                Action::make('print')
                ->label('Cetak')
                ->url(fn (Penjualan $record) => route('penjualan.cetak', $record))
                ->openUrlInNewTab()
                ->icon('heroicon-o-printer'),

                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                // Tables\Actions\BulkActionGroup::make([
                //     Tables\Actions\DeleteBulkAction::make(),
                // ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPenjualans::route('/'),
            'create' => Pages\CreatePenjualan::route('/create'),
            'edit' => Pages\EditPenjualan::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['user', 'details.product']);
    }
    public static function getPermissionPrefixes(): array
    {
        return [
            'view',
            'view_any',
            'create',
            'update',
            'delete',
            'delete_any',
        ];
    }
}
